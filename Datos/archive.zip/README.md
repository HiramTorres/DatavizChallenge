## Visualización de datos para reto de DatavizChallenge por FutureLab 

Se utilizarán algunas librerías para el analisis de datos, y visualización de los mismos como los son: 
* **Pandas**
* **Numpy** 
* **Matplotlib**
----
* **Para leer un archivo**
`df.read_Ext.archivo(url del archivo)` 
``` 

df.read_csv("ArchivoTareas.csv")
```
`df` **Muestra todos los datos del archivo** 
`df.head(n)` **Muestra la "n" cantidad de datos que le asignes de principio a fin** 
`df.tail(n)` **Muestra la "n" cantidad de datos hasta el final**